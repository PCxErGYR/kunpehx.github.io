# Contributors

They helped [develop the app](https://github.com/lwouis/alt-tab-macos/graphs/contributors):

* [adamnemecek](https://github.com/adamnemecek)
* [AfzalivE](https://github.com/AfzalivE)
* [akx](https://github.com/akx)
* [ayroblu](https://github.com/ayroblu)
* [Calinou](https://github.com/Calinou)
* [damonpam](https://github.com/damonpam)
* [gcbw](https://github.com/gcbw)
* [gingerr](https://github.com/gingerr)
* [GrzegorzKazana](https://github.com/GrzegorzKazana)
* [hughlilly](https://github.com/hughlilly)
* [i0ntempest](https://github.com/i0ntempest)
* [karbassi](https://github.com/karbassi)
* [L1cardo](https://github.com/L1cardo)
* [lwouis](https://github.com/lwouis)
* [metacodes](https://github.com/metacodes)
* [mnin](https://github.com/mnin)
* [nella17](https://github.com/nella17)
* [notlmn](https://github.com/notlmn)
* [phungtuanhoang1996](https://github.com/phungtuanhoang1996)
* [rbnis](https://github.com/rbnis)
* [Rjevski](https://github.com/Rjevski)
* [s4na](https://github.com/s4na)
* [samdenty](https://github.com/samdenty)
* [shaqed](https://github.com/shaqed)
* [xanathar](https://github.com/xanathar)
* [zacharee](https://github.com/zacharee)

They helped [localize the app](https://poeditor.com/join/project/8AOEZ0eAZE):

* 73
* Aarni Koskela
* Abdulelah
* Aden Aziz
* Admin
* afuio@qq. com
* Albert Abdilim
* Ali Gokmen
* Allen Guan
* Ameng
* Anurag Roy
* anushree b
* apple
* Arthur
* Ash
* blanorama
* bovirus
* caduellery
* Caner İlhan
* Christian Keilmann
* Chun Fei Lung
* Dan
* Dan84
* David R
* Didier Deschrijver
* Eliezer Shpigelman
* Eric WANTZ
* Ersagun Kuruca
* Eukarya
* fabifabulousity
* Filipe
* Frangarciasalomon
* Frank
* Gezimos
* Giang
* Github
* Gkostov
* Grzegorz Kazana
* Guillaume
* hann-solo
* Haoshuai Xu
* Hjörtur Hjartarson
* Hokuto Kato
* Huandngoc
* Ialiendeg
* Indexerrowaty
* isametry
* Isthereanybody
* Jaeyong Sung
* Jakob
* Jakub Bartušek
* john doe
* Jord Nijhuis
* Julian Nowaczyk
* Kagurazaka Tsuki
* kal
* kant
* Kevinsevinche
* Kim
* Klara
* Kushnee5
* Lcwhhh
* Lester
* LostInCompilation
* Lumaxis
* lwouis
* Maplevantablack
* Marc Pla
* Marekscholle
* Marko McLion
* Martin Mitka
* Martin. mitka
* Max
* MaximilianFreitag
* Michael
* Mohammad Al Zouabi
* Mr. axel. bock
* MuDraconis
* Mwolfinspace
* Nathancodes
* Nikola Rajić
* Nils Fahldieck
* Nilton Souza
* Nmolham
* Ori
* Pehovorka
* Peterkim0620
* Petr Kolář
* ponchik
* Raphaël
* Rasmus
* Raymonf
* rbnis
* sawtooth
* Selcuk Dursun
* Seyedparsa Mirtaheri
* Shameem Reza
* SheNeVmerla
* Shivam Bansal
* Spartak
* Stefan
* Svetoslav Stefanov
* Tomoa Nozawa
* Tran
* Umutakkaya1996
* Vadym
* Vegard
* Vincent Orback
* Vlad
* Webmaster
* Whatsmine-HaoshuaiXu
* ysaito
* Yukai
* yumechan
